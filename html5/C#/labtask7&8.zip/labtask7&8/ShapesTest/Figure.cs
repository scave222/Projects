namespace ShapesTest
{
    public class Figure
    {
        public double x {get; set;}
        public double y {get; set;}
        public string Name {get; set;}

        public Figure(double _x, double _y, string _name)
        {
            x = _x;
            y = _y;
            Name = _name;
        }

        public virtual void area()
        {

        }
    }
}