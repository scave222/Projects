using System;
namespace ShapesTest
{
    public class Triangle : Figure
    {
        

        public Triangle(double _x, double _y, string _name) : base (_x, _y, _name)
        {
            
        }
         public override void area()
        {

             Console.Write("Enter the base: ");
            x = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the height: ");
            y = Convert.ToDouble(Console.ReadLine());   
            Console.Write($"The area of trangle with base: {x} and height: {y} is {(x * y) * 0.5}");
        }
    }
}