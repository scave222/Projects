﻿using System;

namespace Dates
{
    class Program
    {
        static void Main(string[] args)
        {
            Date date = new Date(10, 11, 2019);
            date.DisplayDate();
            Console.ReadLine();
        }
    }
}
