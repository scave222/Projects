﻿using System;

namespace Employ
{
    class Program
    {
        static void Main(string[] args)
        {
             Console.Write($"Enter your first name : ");
            string firstName = Console.ReadLine();

            Console.Write($"Enter your last name : ");
            string lastName = Console.ReadLine();
            
            Console.Write($"Enter your salary : ");
            int salary =Convert.ToInt32(Console.ReadLine());

            Employee employee1 = new Employee (firstName, lastName, salary);

             Console.WriteLine ($"First Nmae:  {employee1.FirstName}\nLast name: {employee1.LastName}\nSalary: {employee1.salaries:C}");
            
        }
    }
}
