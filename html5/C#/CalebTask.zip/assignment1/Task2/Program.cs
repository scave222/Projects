﻿using System;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*");
            Console.WriteLine("* *");
            Console.WriteLine("***");
        }
    }
}
